
public class Deletion1State extends State {
    public Deletion1State(){
        name = "del1";
    }
}
