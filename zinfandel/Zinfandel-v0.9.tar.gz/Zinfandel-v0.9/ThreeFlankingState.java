
public class ThreeFlankingState extends GridState{
    public ThreeFlankingState(String name, int delSize, int gridNumber){
        this.name = name;
        this.delSize = delSize;
        this.gridNumber = gridNumber;
    }
}
