
public class FiveFlankingState extends GridState{
    public FiveFlankingState(String name, int delSize, int gridNumber){
        this.name = name;
        this.delSize = delSize;
        this.gridNumber = gridNumber;
    }
}
