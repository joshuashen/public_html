Readme: Zinfandel, a tool for detecting CNVs from WGS data 

The program requires 3 input files:
1. reference fasta file 
2. Mapview file - alignment from MAQ (http://maq.sourceforge.net/) by Heng Li. 
3. Parameter file with genome type, prior estimated number of CNVs, average CNV size, 
   depth coverage, and readsize 

Running the program
After compiling all the .java files, use command in the following format:
java Main -r reference.fasta -m mapview -p parameters

The fasta file follows the -r argument, mapview file follows -m argument, and parameters
file follows the -p argument.

Note, the arguments can be entered in any order so long as the correct file follows the 
corresponding argument. 
