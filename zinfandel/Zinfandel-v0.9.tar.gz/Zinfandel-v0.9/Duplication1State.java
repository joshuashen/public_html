
public class Duplication1State extends State{
    public Duplication1State(){
        name = "dup1";
    }
}
