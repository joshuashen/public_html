package cnv_hmm;
public class HomozygousFinalState extends GridState{
    public HomozygousFinalState(String name, int delSize, int gridNumber){
        this.name = name;
        this.delSize = delSize;
        this.gridNumber = gridNumber;
    }
}
