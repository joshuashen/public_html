
public class normalState extends State {
    public normalState(){
        name = "normal";
    }
}
