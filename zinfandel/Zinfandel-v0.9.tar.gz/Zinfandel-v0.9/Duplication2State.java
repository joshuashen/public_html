
public class Duplication2State extends State{
    public Duplication2State(){
        name = "dup2";
    }
}
