
public class Deletion2State extends State {
    public Deletion2State(){
        name = "del2";
    }
}
