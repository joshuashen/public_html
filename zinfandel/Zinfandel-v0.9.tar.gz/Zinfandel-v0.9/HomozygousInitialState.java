package cnv_hmm;
public class HomozygousInitialState extends GridState{
    public HomozygousInitialState(String name, int delSize, int gridNumber){
        this.name = name;
        this.delSize = delSize;
        this.gridNumber = gridNumber;
    }
}
